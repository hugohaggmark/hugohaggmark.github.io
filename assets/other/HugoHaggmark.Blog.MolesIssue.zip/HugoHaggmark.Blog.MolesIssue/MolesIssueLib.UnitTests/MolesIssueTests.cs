﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using MolesIssueLib.Moles;

namespace MolesIssueLib.UnitTests
{
    [TestClass]
    public class MolesIssueTests : BaseTests
    {
        [TestMethod]
        public void helloworld_should_return_string_that_contains_hello_world()
        {
            string actual = target.HelloWorld();

            Assert.IsTrue(actual.Contains("Hello World"));
        }

        [TestMethod]
        [HostType("Moles")]
        public void helloworld_should_return_whatever_string_generatehelloworld_returns()
        {
            MMolesIssue.AllInstances.GenerateHelloWorld = (instance) =>
            {
                return generatedHelloWorld;
            };

            string actual = target.HelloWorld();

            Assert.AreEqual(generatedHelloWorld, actual);
        }
    }
}
