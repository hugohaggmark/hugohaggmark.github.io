﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MolesIssueLib.UnitTests
{
    [TestClass]
    public class BaseTests
    {
        protected MolesIssue target;
        protected const string generatedHelloWorld = "Hello World 1";
        protected const string generatedIntegrationHelloWorld = "Hello World 123456789";

        [TestInitialize]
        public void Setup()
        {
            target = new MolesIssue();
        }
    }
}
