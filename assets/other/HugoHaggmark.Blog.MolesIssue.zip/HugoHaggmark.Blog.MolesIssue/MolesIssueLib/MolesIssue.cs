﻿using System;

namespace MolesIssueLib
{
    public class MolesIssue
    {
        public string HelloWorld()
        {
            return GenerateHelloWorld();
        }

        private string GenerateHelloWorld()
        {
            return string.Format("Hello World {0}", new Random().Next());
        }
    }
}
