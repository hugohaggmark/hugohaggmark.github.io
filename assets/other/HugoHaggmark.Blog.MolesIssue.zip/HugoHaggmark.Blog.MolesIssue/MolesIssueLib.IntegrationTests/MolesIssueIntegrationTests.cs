﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using MolesIssueLib.Moles;
using MolesIssueLib.UnitTests;

namespace MolesIssueLib.IntegrationTests
{
    [TestClass]
    public class MolesIssueIntegrationTests : BaseTests
    {
        [TestMethod]
        [HostType("Moles")]
        public void helloworld_should_return_whatever_string_generatehelloworld_returns()
        {
            MMolesIssue.AllInstances.GenerateHelloWorld = (instance) =>
            {
                return generatedIntegrationHelloWorld;
            };

            string actual = target.HelloWorld();

            Assert.AreEqual(generatedIntegrationHelloWorld, actual);
        }
    }
}
