﻿using System;
using System.Net;
using Microsoft.TeamFoundation.Client.Moles;
using Xunit;

namespace HugoHaggmark.Blog.Moles.HowDoIDoMoles.Tests
{
  [Microsoft.VisualStudio.TestTools.UnitTesting.TestClass]
  public class TfsConnectionWrapperTests
  {
    private const string validUrl = "http://valid";

    [Microsoft.VisualStudio.TestTools.UnitTesting.TestMethod, MolesTest]
    [Microsoft.VisualStudio.TestTools.UnitTesting.HostType("Moles")]
    public void using_an_valid_url_string_should_not_throw_the_old_way_I_used_to_do_moles()
    {
      Assert.DoesNotThrow(() =>
      {
        SetupAllMoles();

        TfsConnectionWrapper wrapper = new TfsConnectionWrapper();
        wrapper.Connect(validUrl);
      });
    }

    [Microsoft.VisualStudio.TestTools.UnitTesting.TestMethod, MolesTest]
    [Microsoft.VisualStudio.TestTools.UnitTesting.HostType("Moles")]
    public void using_an_invalid_url_string_should_throw_the_old_way_I_used_to_do_moles()
    {
      Assert.Throws<WebException>(() =>
      {
        SetupAllMoles();

        TfsConnectionWrapper wrapper = new TfsConnectionWrapper();
        wrapper.Connect("http://invalidurl");
      });
    }

    [Microsoft.VisualStudio.TestTools.UnitTesting.TestMethod, MolesTest]
    [Microsoft.VisualStudio.TestTools.UnitTesting.HostType("Moles")]
    public void using_an_valid_url_string_should_not_throw_the_new_way_I_use_moles()
    {
      Assert.DoesNotThrow(() =>
      {
        SetupMolesFactory();

        TfsConnectionWrapper wrapper = new TfsConnectionWrapper();
        wrapper.Connect(TestableTfsTeamProjectCollectionFactory.ValidUrl);
      });
    }

    [Microsoft.VisualStudio.TestTools.UnitTesting.TestMethod, MolesTest]
    [Microsoft.VisualStudio.TestTools.UnitTesting.HostType("Moles")]
    public void using_an_invalid_url_string_should_throw_the_new_way_I_use_moles()
    {
      Assert.Throws<WebException>(() =>
      {
        SetupMolesFactory();

        TfsConnectionWrapper wrapper = new TfsConnectionWrapper();
        wrapper.Connect("http://invalidurl");
      });
    }

    [Microsoft.VisualStudio.TestTools.UnitTesting.TestMethod, MolesTest]
    [Microsoft.VisualStudio.TestTools.UnitTesting.HostType("Moles")]
    public void using_a_connection_that_always_throws_should_throw_the_new_way_I_use_moles()
    {
      Assert.Throws<DivideByZeroException>(() =>
      {
        MolesFactory.SetupMole<TfsConnectionThatThrowsOnConnect>();
        MolesFactory.SetupMole<TestableTfsTeamProjectCollection>();
        MolesFactory.SetupMole<TfsTeamProjectCollectionFactoryThatNeverThrows>();

        TfsConnectionWrapper wrapper = new TfsConnectionWrapper();
        wrapper.Connect("http://invalidurl");
      });
    }

    private static void SetupMolesFactory()
    {
      MolesFactory.SetupMole<TestableTfsConnection>();
      MolesFactory.SetupMole<TestableTfsTeamProjectCollection>();
      MolesFactory.SetupMole<TestableTfsTeamProjectCollectionFactory>();
    }

    private static void SetupAllMoles()
    {
      SetupConnectMole();
      SetupEnsureAuthenticatedMole();
      SetupGetTeamProjectCollectionUriMole();
    }

    private static void SetupConnectMole()
    {
      MTfsConnection.AllInstances.ConnectConnectOptions = (connection, options) =>
      {
      };
    }

    private static void SetupEnsureAuthenticatedMole()
    {
      MTfsConnection.AllInstances.EnsureAuthenticated = (connection) =>
      {
      };
    }

    private static void SetupGetTeamProjectCollectionUriMole()
    {
      MTfsTeamProjectCollection mole = CreateTeamProjectCollectionMole();
      MTfsTeamProjectCollectionFactory.GetTeamProjectCollectionUri = (uri) =>
      {
        if (uri.Equals(new Uri(validUrl)))
          return mole;

        throw new WebException();
      };
    }

    private static MTfsTeamProjectCollection CreateTeamProjectCollectionMole()
    {
      return new MTfsTeamProjectCollection();
    }
  }
}
