﻿using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace HugoHaggmark.Blog.Moles.HowDoIDoMoles.Tests
{
  internal sealed class MolesTestAttribute : TestCategoryBaseAttribute
  {
    public override IList<string> TestCategories
    {
      get { return new[] { "Moles" }; }
    }
  }
}
