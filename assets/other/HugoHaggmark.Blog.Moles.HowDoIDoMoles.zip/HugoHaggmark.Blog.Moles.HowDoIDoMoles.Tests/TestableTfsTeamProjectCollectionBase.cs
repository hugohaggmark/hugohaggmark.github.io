﻿using Microsoft.TeamFoundation.Client.Moles;

namespace HugoHaggmark.Blog.Moles.HowDoIDoMoles.Tests
{
  internal abstract class TestableTfsTeamProjectCollectionBase : MTfsTeamProjectCollection
  {
    protected TestableTfsTeamProjectCollectionBase()
    {
    }
  }
}
