﻿namespace HugoHaggmark.Blog.Moles.HowDoIDoMoles.Tests
{
internal class TestableTfsConnection : TestableTfsConnectionBase
{
}
}
