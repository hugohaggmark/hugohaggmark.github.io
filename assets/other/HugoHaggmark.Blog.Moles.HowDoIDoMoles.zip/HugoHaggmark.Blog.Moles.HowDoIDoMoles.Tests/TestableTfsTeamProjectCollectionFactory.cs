﻿
namespace HugoHaggmark.Blog.Moles.HowDoIDoMoles.Tests
{
  internal class TestableTfsTeamProjectCollectionFactory : TestableTfsTeamProjectCollectionFactoryBase
  {
  }
}
