﻿
namespace HugoHaggmark.Blog.Moles.HowDoIDoMoles.Tests
{
  internal class MolesFactory
  {
    public static void SetupMole<M>() where M : class, new()
    {
      M mole = new M();
    }
  }
}
