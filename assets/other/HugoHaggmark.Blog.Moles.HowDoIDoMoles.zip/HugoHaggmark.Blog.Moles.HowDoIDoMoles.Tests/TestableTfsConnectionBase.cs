﻿using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.Client.Moles;
using Microsoft.TeamFoundation.Framework.Common;

namespace HugoHaggmark.Blog.Moles.HowDoIDoMoles.Tests
{
  internal abstract class TestableTfsConnectionBase : MTfsConnection
  {
    protected TestableTfsConnectionBase()
      : base(new MTfsTeamProjectCollection())
    {
      InitConnectMole();
      InitEnsureAuthenticatedMole();
    }

    private void InitEnsureAuthenticatedMole()
    {
      AllInstances.EnsureAuthenticated = (connection) =>
      {
        SetupEnsureAuthenticatedMole(connection);
      };
    }

    private void InitConnectMole()
    {
      AllInstances.ConnectConnectOptions = (connection, options) =>
      {
        SetupConnectMole(connection, options);
      };
    }

    protected virtual void SetupConnectMole(TfsConnection connection, ConnectOptions options)
    {
    }

    protected virtual void SetupEnsureAuthenticatedMole(TfsConnection connection)
    {
    }
  }
}
