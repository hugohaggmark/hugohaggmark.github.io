﻿using System;
using Microsoft.TeamFoundation.Client;

namespace HugoHaggmark.Blog.Moles.HowDoIDoMoles.Tests
{
  internal class TfsTeamProjectCollectionFactoryThatNeverThrows : TestableTfsTeamProjectCollectionFactoryBase
  {
    protected override TfsTeamProjectCollection SetupGetTeamProjectCollectionUriMole(Uri uri)
    {
      return new TestableTfsTeamProjectCollection();
    }
  }
}
