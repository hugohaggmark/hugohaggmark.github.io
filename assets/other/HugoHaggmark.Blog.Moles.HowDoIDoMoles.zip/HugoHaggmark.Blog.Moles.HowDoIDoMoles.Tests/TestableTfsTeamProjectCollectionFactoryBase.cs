﻿using System;
using System.Net;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.Client.Moles;

namespace HugoHaggmark.Blog.Moles.HowDoIDoMoles.Tests
{
  internal abstract class TestableTfsTeamProjectCollectionFactoryBase
  {
    public const string ValidUrl = "http://validuri";

    protected TestableTfsTeamProjectCollectionFactoryBase()
    {
      MTfsTeamProjectCollectionFactory.GetTeamProjectCollectionUri = (uri) =>
      {
        return SetupGetTeamProjectCollectionUriMole(uri);
      };
    }

    protected virtual TfsTeamProjectCollection SetupGetTeamProjectCollectionUriMole(Uri uri)
    {
      if (uri.Equals(new Uri(ValidUrl)))
        return new TestableTfsTeamProjectCollection();

      throw new WebException();
    }
  }
}
