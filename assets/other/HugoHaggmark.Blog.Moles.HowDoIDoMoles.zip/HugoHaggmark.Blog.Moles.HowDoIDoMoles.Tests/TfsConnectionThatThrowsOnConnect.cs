﻿using System;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.Framework.Common;

namespace HugoHaggmark.Blog.Moles.HowDoIDoMoles.Tests
{
  internal class TfsConnectionThatThrowsOnConnect : TestableTfsConnectionBase
  {
    protected override void SetupConnectMole(TfsConnection connection, ConnectOptions options)
    {
      throw new DivideByZeroException();
    }
  }
}
