﻿using System;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.Framework.Common;

namespace HugoHaggmark.Blog.Moles.HowDoIDoMoles
{
  public class TfsConnectionWrapper
  {
    private TfsTeamProjectCollection tfsTpc;

    public TfsConnectionWrapper()
    {

    }

    public void Connect(string url)
    {
      tfsTpc = TfsTeamProjectCollectionFactory.GetTeamProjectCollection(
        new Uri(url));
      tfsTpc.Connect(ConnectOptions.None);
      tfsTpc.EnsureAuthenticated();
    }
  }
}
